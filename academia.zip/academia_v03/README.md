# Academia 0.3

A standalone, dependency-free mobile-friendly academic planner.

## Try it
Open `index.html` in your browser. For installable PWA/offline shell, serve the directory over HTTPS or localhost. The single-file HTML works offline once downloaded, without any backend. Google Fonts are optional and fall back to system fonts.

For local development:

```bash
python -m http.server 8080
```

Open http://localhost:8080/index.html .

## Features
- Home: Quick Add first, tasks and upcoming agenda.
- Tasks: quick completion, optional subtasks, subjects, deadlines, edit/delete/search.
- Calendar: month/agenda/study schedule and type filters. Deadline is a date, while study and exams have time blocks.
- Competitions: always-visible timeline and completion toggles. Every stage is included in the calendar.
- Study planning: time interval, date span, daily/weekly recurrence with optional weekdays and end date.
- Local persistence (`localStorage`) and JSON backup/restore. Demo records can be cleared from Settings.

## AI agent integration
The app currently uses a small, offline keyword/date parser in `quickParse()`. There is **no cloud AI** in this version. Replace this parser later with a server-side LLM endpoint returning a validated object with `type`, `title`, `startDate`, `endDate`, `startTime`, `endTime`, `repeat`, and `repeatDays`. Avoid storing provider API keys in frontend JavaScript. Do not invent missing dates; return nulls, or ask for clarification. Persist through `quickSave()` only after validating input.

## Data format
Local storage key `academia-clean-v03`. Three primary collections: `tasks`, `activities`, `competitions`. The calendar produces read-only combined occurrences. Recurrence is calculated dynamically and individual tasks are not duplicated in storage.

## Notes
The initial demo includes sample activities, not actual due dates. Use the settings menu to clear demo data. Browser storage is device and browser-specific. It does not sync across devices or account for private mode and cache clearing.
